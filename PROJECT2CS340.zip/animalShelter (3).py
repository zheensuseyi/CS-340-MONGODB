from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS, host, port, database, collection):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        #USER = 'aacuser'
        #PASS = 'admin'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31522
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
# Complete this create method to implement the C in CRUD.
    def create(self, data):
        # If data is not empty
        if data is not None:
            # Insert animal 
            self.database.animals.insert_one(data)  # data should be dictionary 
		    # Return true so we know it works
            return True     
        else:
            # Error handling
            raise Exception("Nothing to save, because data parameter is empty")
            # Unsuccesful insert return false
            return False
# Create method to implement the R in CRUD.
    def read(self, query):
        # If query is not empty
        if query is not None:
            # Find query
            readResult = self.collection.find(query)
          
            # Return query result in list 
            return list(readResult)
        else:
            # Error handling
            raise Exception("Nothing to read, because query parameter is empty")
            # Return empty list if unsuccessful
            return list()
        
# Create method to implement the U in CRUD.
    def update(self, query, newUpdate):
          # If query exists
          if query is not None:
              # Finding and updating the document
              changedDoc = self.collection.find_one_and_update(query, {"$set": newUpdate})
              
              # If document was successfully found and updated
              if changedDoc:
                  print("The Following Document Was Modified: ")
                  return changedDoc
              
              # If not successful
              else:
                  raise Exception("Couldn't find document, perhaps it doesn't exist anymore.")
                  
          # If query parameter is empty
          else:
              raise Exception("Nothing to update, because query parameter is empty.")
    def delete(self, query):
         # If query exists
         if query is not None:
             # Finding and deleting the document
             self.collection.find_one_and_delete(query)
             # Print statement for document deletion
             printstatement = print("Object succcessfully deleted")
             # Returning our print statement
             return(printstatement)
         else:
             raise Exception("Nothing to delete, because query parameter is empty.")